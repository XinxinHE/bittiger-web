export class Course {
    cid: number;
    name: string;
    week: number;
    desc: string;
    teacher: string;
}