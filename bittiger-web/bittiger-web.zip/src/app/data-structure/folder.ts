export class Folder {
    fid: number;
    name: string;
    courses: number[];
}