import { Course } from '../data-structure/course';

export const COURSES: Course[] = [
{
    cid: 1,
    name: 'Intro to Project Manager Class',
    week: 1,
    desc: 'This course introduces the basic concepts of PM',
    teacher: 'Payson Wu'
}, 
{
    cid: 2,
    name: 'Intro to Project Manager Class',
    week: 1,
    desc: 'This course introduces the basic concepts of PM',
    teacher: 'Payson Wu'
},
{
    cid: 3,
    name: 'Intro to Project Manager Class',
    week: 2,
    desc: 'This course introduces the basic concepts of PM',
    teacher: 'Payson Wu'
},
{    
    cid: 4,
    name: 'Intro to Project Manager Class',
    week: 3,
    desc: 'This course introduces the basic concepts of PM',
    teacher: 'Payson Wu'

},
{    
    cid: 5,
    name: 'Intro to Project Manager Class',
    week: 3,
    desc: 'This course introduces the basic concepts of PM',
    teacher: 'Payson Wu'
},
{    
    cid: 6,
    name: 'Intro to Project Manager Class',
    week: 3,
    desc: 'This course introduces the basic concepts of PM',
    teacher: 'Payson Wu'

},
{    
    cid: 7,
    name: 'Intro to Project Manager Class',
    week: 4,
    desc: 'This course introduces the basic concepts of PM',
    teacher: 'Payson Wu'

}];
